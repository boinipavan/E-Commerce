# Product
Full frontend and backend ( Angular , Spring Boot and MYSQL )                                                                                                      
                                                                                                                                                                     
Steps to run the application                                                                                                                                   
In backend Step1: Add the product to the worspace using intellij , sts , etc(depends on your choice).                                                                     
Step2: Change the configuation in application.properties according to your system.                                                                                  
       (change mysql username and password in configuration file)                                                                                                    
Step3: Run the backend.                                                                                                                                        
                                                                                                                                                                   
In frontend                                                                                                                                                               
Step4: Open the app in vs code.                                                                                                                                   
Step5: Install npm using command : npm install                                                                                                                           
Step6: Run the application using command : ng serve                                                                                                                
Step7: Open any web browser                                                                                                                                      
       type : localhost:4200                                                                                                                                    
                                                                                                                                                                 
=============IMPORTANT================                                                                                                                           
Full frontend and backend ( Angular , Spring Boot and MongoDB ) added in another branch                                                                         
(change configuration file according to your system)                                                                                                           
                                                                                                                                                                     
To pull from that branch use the command :-                                                                                                                               
git clone --branch ecommerce_using_mongo https://github.com/codreal-yt/E-Commerce.git                                                                           
                                                                                                                                                                
(If getting any error, Ping me in Youtube channel comment box or in telegram channel)                                                                         
                                                                                                                                                              
======================================                                                                                                                       
                                                                                                                                                                      
                                                                                                                                                                        
Like, share and subscribe to my channel for more updates.                                                                                                                 
https://www.youtube.com/@codreal                                                                                                                                         
                                                                                                                                                                         
Thank You                                                                                                                                                                 
                                                                                                                                               
