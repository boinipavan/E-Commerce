export class Product {

    pid?:Number;
    pname?:string;
    pcategory?:string;
    pdatepost?:string;
    description?:string;
    pcity?:string;
    pcoin?:Number;
  image: any;
    
    // image:[byte];
    

constructor(){}

}
