package com.pavan.product.exceptions;

public class NoProductExistInRepository extends Throwable {
}
