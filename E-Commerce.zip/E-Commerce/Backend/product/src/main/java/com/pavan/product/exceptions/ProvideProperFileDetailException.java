package com.pavan.product.exceptions;

public class ProvideProperFileDetailException extends Throwable {
}
